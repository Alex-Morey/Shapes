import java.awt.Point;

/**
 * Abstract base class for all shapes.
 * A shape is defined by two points and a color.
 *
 * @author Alexander Morey
 * @version 1.0
 */
public abstract class Shape {

    private Point point1;
    private Point point2;
    private double color;

    /**
     * Constructs a Shape with two points and a color.
     *
     * @param point1 the first point (not null)
     * @param point2 the second point (not null)
     * @param color the color value
     * @throws IllegalArgumentException if either point is null
     */
    public Shape(Point point1, Point point2, double color) {
        if (point1 == null || point2 == null) {
            throw new IllegalArgumentException("Points cannot be null");
        }
        this.point1 = point1;
        this.point2 = point2;
        this.color = color;
    }

    /**
     * Returns the first point.
     *
     * @return the first point
     */
    public Point getPoint1() {
        return point1;
    }

    /**
     * Returns the second point.
     *
     * @return the second point
     */
    public Point getPoint2() {
        return point2;
    }

    /**
     * Returns the color value.
     *
     * @return the color value
     */
    public double getColor() {
        return color;
    }

    /**
     * Prints the shape to the terminal.
     */
    public abstract void draw();
}




import java.awt.Point;

/**
 * Represents an oval defined by two points and a color.
 *
 * @author Alexander Morey
 * @version 1.0
 */
public class Oval extends Shape {

    /**
     * Constructs an Oval with two points and a color.
     *
     * @param point1 the first point
     * @param point2 the second point
     * @param color the color value
     */
    public Oval(Point point1, Point point2, double color) {
        super(point1, point2, color);
    }

    /**
     * Prints "Oval" to the terminal.
     */
    public void draw() {
        System.out.print("Oval");
    }
}


